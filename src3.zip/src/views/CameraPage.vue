<template>
    
      <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>Camera</ion-title>
      </ion-toolbar>
    </ion-header>
 
        <ion-content :fullscreen="true">
    <ion-fab vertical="bottom" horizontal="center" slot="fixed">
      <ion-fab-button @click="takePhoto()">
        <ion-icon :icon="camera"></ion-icon>
      </ion-fab-button>
    </ion-fab>
    <ion-grid>
      <ion-row>
        <ion-col size="6" :key="photo.webviewPath" v-for="photo in photos">
          <ion-img :src="photo.webviewPath"></ion-img>
        </ion-col>
      </ion-row>
    </ion-grid>
  
    <!-- <ion-fab> markup  -->
 <!--<ion-tab-button tab="tab2" href="/tabs/tab2">
    <ion-icon :icon="images" />
    <ion-label>Photos</ion-label>
  </ion-tab-button>--> 
  </ion-content>
  <ion-footer>
    <ion-button router-link="/test">test </ion-button>
    <ion-button router-link="/home">home </ion-button>
    <ion-button router-link="/camera">camera </ion-button>
    <ion-button @click='getList()'>call api</ion-button>

</ion-footer>
</ion-page>

    </template>
    
    <script lang="ts">
    import { Checkbox } from '@ionic/core/dist/types/components/checkbox/checkbox';
  import { IonButton,IonFooter,IonTitle,IonToolbar,IonHeader,IonPage,IonGrid,IonImg, IonFabButton, IonIcon,IonFab,IonContent ,IonCol,IonRow } from '@ionic/vue';
    import { defineComponent } from 'vue';
    import OneSignal from 'onesignal-cordova-plugin';
    import { usePhotoGallery,UserPhoto } from '@/composables/usePhotoGallery';
    import { camera, trash, close } from 'ionicons/icons';
    import { images, square, triangle } from 'ionicons/icons';
    import axios from 'axios'

    export default defineComponent({
      components: {IonButton,IonFooter,IonTitle,IonToolbar,IonHeader,IonPage,IonGrid,IonImg,IonFabButton, IonIcon,IonFab,IonContent ,IonCol,IonRow  },
      setup() {
      const { photos ,takePhoto } = usePhotoGallery();
      return {  
        photos,
        images,
        square,
        triangle,
        takePhoto,
        camera, trash, close
      }
    },
      data(){
    return {
      ArrMatiere :[{ name:'phy',check:true },{ name:'algo',check:true },{ name:'info',check:false }] ,
       CheckboxMatier : '',
      btnradio :'' ,
      nom: '' ,
      selected :'',
      civilite : 'hhc',
      ArrCivilite : ['mme','mr'],
      Arrspecialite: ['info','math'],
      msg :''
  
    };
  },
  methods: {
    getList() {
      axios.get("http://localhost:8081/get/image/info/45").then((response) => {
        console.log(response.data)
      })
      .catch((error) => {
                console.log(error)
            }) },
    send() {
      let nom_prenom = this.civilite=" "+this.nom ;
      let mat :any =''
      this.ArrMatiere.forEach((value, index) => {
    if (value.check)  {
  mat =mat+ value.name
    }
  });
  this.msg = nom_prenom+`pécialité : ` +this.btnradio+" matière : "+mat
  let data :any = [{nom :nom_prenom,matiere:mat,specialite :this.btnradio}]
  this.$router.push({
      name: "Home",
      query: { data: JSON.stringify(data) }
    });
  }
  ,
    CiviliteOption(event :any ) {
      this.selected = event
              console.log(event)
          },
          specialite(event :any ) {
     /* this.btnradio = event
              console.log(event)*/
          },
      },
      mounted: function(){
     //  alert('hh)')
  //this.OneSignalInit()
  },
  
  });
  
    
    </script> <style scoped>
    ion-radio {
      --border-radius: 4px;
      --inner-border-radius: 4px;
  
      --color: #ddd;
      --color-checked: #6815ec;
    }
  
    ion-radio.ios {
      width: 20px;
      height: 20px;
  
      border: 2px solid #ddd;
      border-radius: 4px;
    }
  
    .radio-checked.ios {
      border-color: #6815ec;
    }
  </style>