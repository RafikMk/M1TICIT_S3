import { ref, onMounted, watch } from 'vue';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import axios from 'axios'
import { Directory, Filesystem } from '@capacitor/filesystem';

  export interface UserPhoto {
    filepath: string;
    webviewPath?: string;
  }
export function usePhotoGallery() {
      const photos = ref<UserPhoto[]>([]);
    const takePhoto = async (update :any,ob :any ) => {
      const photo = await Camera.getPhoto({
        resultType: CameraResultType.Uri,
        source: CameraSource.Camera,
        quality: 100,
      });
     
   /*  const picture = 'data:image/jpg;base64,' + photo;
      console.log(picture)

      fetch(picture)
.then(res => res.blob())
.then(blob => {
  const fd = new FormData()
  fd.append('image', blob, 'filename')
  
  console.log(blob)
})
  // Upload
  // fetch('upload', {method: 'POST', body: fd})

  const response = await fetch(picture);
  const blob = await response.blob();
  const formData = new FormData();
  formData.append('file', blob, picture);
 
  axios.post("http://localhost:8081/upload/image").then((response) => {
        console.log(response.data)
      })
      .catch((error) => {
                console.log(error)
            }) 

      
console.log(picture) ;
*/

      const fileName = new Date().getTime() + '.jpeg';
     // const savedFileImage = { filepath: fileName, webviewPath: photo.webPath, };
  
 const savedFileImage = await savePicture(update,ob,photo, fileName);
 // photos.value = [savedFileImage, ...photos.value];

  
  

    };
  
    return {
    photos ,
      takePhoto,
    };
  }
  const convertBlobToBase64 = (blob: Blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      resolve(reader.result);
    };
    reader.readAsDataURL(blob);
  });
  const savePicture = async (update : any,ob :any ,photo: Photo, fileName: string): Promise<UserPhoto> => {
    let base64Data: string;
    // Fetch the photo, read as a blob, then convert to base64 format
    const response = await fetch(photo.webPath!);
    const blob = await response.blob();
    console.log(blob)
    const fd = new FormData()
    //fd.append('image', blob, 'llll')
    if (update == "update")
    {   
   //   let Img = response.data.toString();
      const Img = ob.name+"Updated" ;
      fd.append('image', blob, Img)
      axios.post(`http://localhost:8081/update/image/${ob.id}`,fd).then((response) => {
        console.log(response.data)
      })
      .catch((error) => {
                console.log(error)
            })
    }
    else {
    axios.get("http://localhost:8081/get/imageNumbers").then((response) => {
      console.log(response.data)
      let Img = response.data.toString();
      Img = "Image_N_"+Img
      fd.append('image', blob, Img)
      axios.post("http://localhost:8081/upload/image",fd).then((response) => {
        console.log(response.data)
      })
      .catch((error) => {
                console.log(error)
            })
    })
    .catch((error) => {
              console.log(error)
          })
        }
        
  //  base64Data = (await convertBlobToBase64(blob)) as string;
  
  //  const savedFile = await Filesystem.writeFile({
  //    path: fileName,
   //   data: base64Data,
   //   directory: Directory.Data,
   // });
  
    // Use webPath to display the new image instead of base64 since it's
    // already loaded into memory
    return {
      filepath: fileName,
      webviewPath: photo.webPath,
    };
  };
